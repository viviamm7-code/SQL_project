package org.example.model1;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AlbumTO {
	private String seq;
	private String subject;
	private String writer;
	private String mail;
	private String password;
	private String content;
	private String imageName;
	private long imageSize;
	private String hit;
	private String wip;
	private String wdate;
	private int wgap;
}
