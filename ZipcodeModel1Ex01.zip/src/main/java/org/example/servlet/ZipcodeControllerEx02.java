package org.example.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.model2.Action;
import org.example.model2.ZipcodeAction;
import org.example.model2.ZipcodeOkAction;

import java.io.IOException;

@WebServlet( urlPatterns = "*.do" )
public class ZipcodeControllerEx02 extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doProcess( req, resp );
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doProcess( req, resp );
	}

	protected void doProcess(HttpServletRequest req, HttpServletResponse resp) {

		try {
			String path = req.getServletPath();

			String url = "";
			Action action = null;
			if( path.equals( "/zipcode.do" ) ) {
				action = new ZipcodeAction();
				action.execute( req, resp );

				url = "/WEB-INF/views4/zipcode.jsp";
			} else if( path.equals( "/zipcode_ok.do" ) ) {
				action = new ZipcodeOkAction();
				action.execute( req, resp );

				url = "/WEB-INF/views4/zipcode_ok.jsp";
			}

			RequestDispatcher dispatcher = req.getRequestDispatcher(url);
			dispatcher.forward( req, resp );
		} catch (ServletException e) {
			System.out.println( "[에러] " + e.getMessage() );
		} catch (IOException e) {
			System.out.println( "[에러] " + e.getMessage() );
		}
	}
}
