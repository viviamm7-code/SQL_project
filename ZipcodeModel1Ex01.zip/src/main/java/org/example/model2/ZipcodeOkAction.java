package org.example.model2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.model1.ZipcodeDAO;
import org.example.model1.ZipcodeTO;

import java.util.ArrayList;

public class ZipcodeOkAction implements Action {
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println( "ZipcodeOkAciton 호출" );

		String searchDong = req.getParameter( "searchDong" );

		ZipcodeDAO dao = new ZipcodeDAO();
		ArrayList<ZipcodeTO> lists = dao.selectZipcode3( searchDong );

		req.setAttribute( "lists", lists );
	}
}
